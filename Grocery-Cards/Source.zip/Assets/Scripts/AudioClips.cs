using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioClips : MonoBehaviour
{
    public AudioClip[] cardPickupClips;
    public AudioClip[] cardDepositClips;
    public AudioClip[] bagDepositClips;
}
