using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueClips : MonoBehaviour
{
    public AudioClip[] NPC1Clips;
    public AudioClip[] NPC2Clips;
    public AudioClip[] NPC3Clips;
    public AudioClip[] NPC4Clips;
}
